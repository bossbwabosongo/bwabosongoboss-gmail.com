package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.util.QrCodeDecoder
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("SmartCampus", appName)
    }

    @Test
    fun `test qr code payload parsing`() {
        val payload = "SMARTCAMPUS:STUDENT:SC-2024-001:Lucas:Dubois:Terminale S1"
        val parsed = QrCodeDecoder.parsePayload(payload)
        assertEquals("SC-2024-001", parsed.matricule)
        assertEquals("Lucas", parsed.firstName)
        assertEquals("Dubois", parsed.lastName)
        assertEquals("Terminale S1", parsed.className)
    }
}
