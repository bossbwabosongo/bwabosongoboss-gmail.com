package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand palette - Academic Deep Blue & Emerald Campus Security
val CampusPrimary = Color(0xFF1D4ED8)
val CampusPrimaryDark = Color(0xFF1E3A8A)
val CampusPrimaryContainer = Color(0xFFDBEAFE)
val CampusOnPrimaryContainer = Color(0xFF1E3A8A)

val CampusSecondary = Color(0xFF0D9488)
val CampusSecondaryContainer = Color(0xFFCCFBF1)
val CampusOnSecondaryContainer = Color(0xFF115E59)

val CampusTertiary = Color(0xFFF59E0B)
val CampusTertiaryContainer = Color(0xFFFEF3C7)
val CampusOnTertiaryContainer = Color(0xFF92400E)

val CampusError = Color(0xFFEF4444)
val CampusErrorContainer = Color(0xFFFEE2E2)
val CampusOnErrorContainer = Color(0xFF991B1B)

val CampusSuccess = Color(0xFF10B981)
val CampusSuccessContainer = Color(0xFFD1FAE5)
val CampusOnSuccessContainer = Color(0xFF065F46)

// Surface colors
val CampusBackground = Color(0xFFF8FAFC)
val CampusSurface = Color(0xFFFFFFFF)
val CampusSurfaceVariant = Color(0xFFF1F5F9)
val CampusTextPrimary = Color(0xFF0F172A)
val CampusTextSecondary = Color(0xFF475569)
val CampusBorder = Color(0xFFE2E8F0)

// Dark Theme Variants
val CampusPrimaryDarkTheme = Color(0xFF93C5FD)
val CampusSecondaryDarkTheme = Color(0xFF5EEAD4)
val CampusTertiaryDarkTheme = Color(0xFFFCD34D)
val CampusBackgroundDark = Color(0xFF0B132B)
val CampusSurfaceDark = Color(0xFF1C2541)
val CampusSurfaceVariantDark = Color(0xFF263353)
val CampusTextPrimaryDark = Color(0xFFF1F5F9)
val CampusTextSecondaryDark = Color(0xFF94A3B8)
