package com.example.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.Announcement
import com.example.data.model.AttendanceRecord
import com.example.data.model.CourseSession
import com.example.data.model.Grade
import com.example.data.model.Homework
import com.example.data.model.IncidentReport
import com.example.data.model.Student
import kotlinx.coroutines.flow.Flow

@Dao
interface CampusDao {

    // Students
    @Query("SELECT * FROM students ORDER BY lastName, firstName")
    fun getAllStudents(): Flow<List<Student>>

    @Query("SELECT * FROM students WHERE id = :id LIMIT 1")
    fun getStudentById(id: Long): Flow<Student?>

    @Query("SELECT * FROM students WHERE matricule = :matricule LIMIT 1")
    suspend fun getStudentByMatricule(matricule: String): Student?

    @Query("SELECT * FROM students WHERE qrCodePayload = :payload LIMIT 1")
    suspend fun getStudentByPayload(payload: String): Student?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStudents(students: List<Student>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStudent(student: Student): Long

    // Attendance
    @Query("SELECT * FROM attendance_records ORDER BY timestamp DESC")
    fun getAllAttendance(): Flow<List<AttendanceRecord>>

    @Query("SELECT * FROM attendance_records WHERE studentId = :studentId ORDER BY timestamp DESC")
    fun getAttendanceForStudent(studentId: Long): Flow<List<AttendanceRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAttendance(record: AttendanceRecord): Long

    // Courses
    @Query("SELECT * FROM courses ORDER BY dayOfWeek, startTime")
    fun getAllCourses(): Flow<List<CourseSession>>

    @Query("SELECT * FROM courses WHERE dayOfWeek = :dayOfWeek ORDER BY startTime")
    fun getCoursesForDay(dayOfWeek: Int): Flow<List<CourseSession>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCourses(courses: List<CourseSession>)

    // Homework
    @Query("SELECT * FROM homeworks ORDER BY isCompleted ASC, dueTimestamp ASC")
    fun getAllHomework(): Flow<List<Homework>>

    @Query("SELECT * FROM homeworks WHERE studentId = :studentId ORDER BY isCompleted ASC, dueTimestamp ASC")
    fun getHomeworkForStudent(studentId: Long): Flow<List<Homework>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHomework(homework: Homework): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHomeworks(homeworks: List<Homework>)

    @Update
    suspend fun updateHomework(homework: Homework)

    @Query("DELETE FROM homeworks WHERE id = :id")
    suspend fun deleteHomework(id: Long)

    // Grades
    @Query("SELECT * FROM grades ORDER BY id DESC")
    fun getAllGrades(): Flow<List<Grade>>

    @Query("SELECT * FROM grades WHERE studentId = :studentId ORDER BY id DESC")
    fun getGradesForStudent(studentId: Long): Flow<List<Grade>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGrades(grades: List<Grade>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGrade(grade: Grade): Long

    // Announcements
    @Query("SELECT * FROM announcements ORDER BY isPinned DESC, timestamp DESC")
    fun getAllAnnouncements(): Flow<List<Announcement>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAnnouncements(announcements: List<Announcement>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAnnouncement(announcement: Announcement): Long

    // Incidents & Security
    @Query("SELECT * FROM incidents ORDER BY timestamp DESC")
    fun getAllIncidents(): Flow<List<IncidentReport>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertIncident(incident: IncidentReport): Long

    @Query("UPDATE incidents SET status = :status, resolvedNote = :note WHERE id = :id")
    suspend fun updateIncidentStatus(id: Long, status: String, note: String)
}
