package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.dao.CampusDao
import com.example.data.model.Announcement
import com.example.data.model.AttendanceRecord
import com.example.data.model.CourseSession
import com.example.data.model.Grade
import com.example.data.model.Homework
import com.example.data.model.IncidentReport
import com.example.data.model.Student
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        Student::class,
        AttendanceRecord::class,
        CourseSession::class,
        Homework::class,
        Grade::class,
        Announcement::class,
        IncidentReport::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun campusDao(): CampusDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "smart_campus.db"
                )
                    .addCallback(DatabaseCallback(scope))
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback(
            private val scope: CoroutineScope
        ) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        populateInitialData(database.campusDao())
                    }
                }
            }
        }

        suspend fun populateInitialData(dao: CampusDao) {
            // Seed Students
            val students = listOf(
                Student(
                    id = 1,
                    matricule = "SC-2024-001",
                    firstName = "Lucas",
                    lastName = "Dubois",
                    className = "Terminale S1",
                    birthDate = "14/05/2007",
                    bloodGroup = "A+",
                    parentName = "Marc & Sophie Dubois",
                    parentPhone = "+33 6 12 34 56 78",
                    email = "lucas.dubois@campus.edu",
                    avatarColorHex = "#1D4ED8",
                    qrCodePayload = "SMARTCAMPUS:STUDENT:SC-2024-001:Lucas:Dubois:Terminale S1"
                ),
                Student(
                    id = 2,
                    matricule = "SC-2024-002",
                    firstName = "Inès",
                    lastName = "Benali",
                    className = "Terminale S1",
                    birthDate = "22/09/2007",
                    bloodGroup = "O+",
                    parentName = "Karim Benali",
                    parentPhone = "+33 6 98 76 54 32",
                    email = "ines.benali@campus.edu",
                    avatarColorHex = "#0D9488",
                    qrCodePayload = "SMARTCAMPUS:STUDENT:SC-2024-002:Inès:Benali:Terminale S1"
                ),
                Student(
                    id = 3,
                    matricule = "SC-2024-003",
                    firstName = "Thomas",
                    lastName = "Leroy",
                    className = "1ère Générale",
                    birthDate = "03/11/2008",
                    bloodGroup = "B+",
                    parentName = "Isabelle Leroy",
                    parentPhone = "+33 6 45 67 89 01",
                    email = "thomas.leroy@campus.edu",
                    avatarColorHex = "#F59E0B",
                    qrCodePayload = "SMARTCAMPUS:STUDENT:SC-2024-003:Thomas:Leroy:1ère Générale"
                ),
                Student(
                    id = 4,
                    matricule = "SC-2024-004",
                    firstName = "Emma",
                    lastName = "Moreau",
                    className = "Terminale S1",
                    birthDate = "18/02/2007",
                    bloodGroup = "AB+",
                    parentName = "Philippe Moreau",
                    parentPhone = "+33 6 77 88 99 00",
                    email = "emma.moreau@campus.edu",
                    avatarColorHex = "#8B5CF6",
                    qrCodePayload = "SMARTCAMPUS:STUDENT:SC-2024-004:Emma:Moreau:Terminale S1"
                )
            )
            dao.insertStudents(students)

            // Seed Attendance Records
            val now = System.currentTimeMillis()
            val hourMs = 3600000L
            val records = listOf(
                AttendanceRecord(
                    id = 1,
                    studentId = 1,
                    studentMatricule = "SC-2024-001",
                    studentName = "Lucas Dubois",
                    className = "Terminale S1",
                    timestamp = now - (hourMs * 8),
                    type = "ENTREE",
                    status = "A_L_HEURE",
                    checkpoint = "Portail Principal"
                ),
                AttendanceRecord(
                    id = 2,
                    studentId = 2,
                    studentMatricule = "SC-2024-002",
                    studentName = "Inès Benali",
                    className = "Terminale S1",
                    timestamp = now - (hourMs * 7) - (15 * 60000L),
                    type = "ENTREE",
                    status = "RETARD",
                    checkpoint = "Portail Principal"
                ),
                AttendanceRecord(
                    id = 3,
                    studentId = 3,
                    studentMatricule = "SC-2024-003",
                    studentName = "Thomas Leroy",
                    className = "1ère Générale",
                    timestamp = now - (hourMs * 8) + (10 * 60000L),
                    type = "ENTREE",
                    status = "A_L_HEURE",
                    checkpoint = "Portail Bâtiment Ouest"
                ),
                AttendanceRecord(
                    id = 4,
                    studentId = 1,
                    studentMatricule = "SC-2024-001",
                    studentName = "Lucas Dubois",
                    className = "Terminale S1",
                    timestamp = now - (hourMs * 24),
                    type = "ENTREE",
                    status = "A_L_HEURE",
                    checkpoint = "Portail Principal"
                ),
                AttendanceRecord(
                    id = 5,
                    studentId = 1,
                    studentMatricule = "SC-2024-001",
                    studentName = "Lucas Dubois",
                    className = "Terminale S1",
                    timestamp = now - (hourMs * 16),
                    type = "SORTIE",
                    status = "A_L_HEURE",
                    checkpoint = "Portail Principal"
                )
            )
            for (rec in records) {
                dao.insertAttendance(rec)
            }

            // Seed Timetable / Courses
            val courses = listOf(
                CourseSession(id = 1, subject = "Mathématiques Spécialité", teacherName = "M. Laurent", room = "Salle 204", dayOfWeek = 1, startTime = "08:00", endTime = "10:00", colorHex = "#1D4ED8"),
                CourseSession(id = 2, subject = "Physique-Chimie", teacherName = "Mme. Rousseau", room = "Labo B3", dayOfWeek = 1, startTime = "10:15", endTime = "12:15", colorHex = "#0D9488"),
                CourseSession(id = 3, subject = "Philosophie", teacherName = "M. Vasseur", room = "Salle 108", dayOfWeek = 1, startTime = "13:30", endTime = "15:30", colorHex = "#8B5CF6"),
                CourseSession(id = 4, subject = "Anglais LV1", teacherName = "Mrs. Cooper", room = "Salle 210", dayOfWeek = 2, startTime = "08:30", endTime = "10:00", colorHex = "#F59E0B"),
                CourseSession(id = 5, subject = "Sciences de la Vie & Terre", teacherName = "Mme. Martin", room = "Labo SVT 1", dayOfWeek = 2, startTime = "10:15", endTime = "12:15", colorHex = "#10B981"),
                CourseSession(id = 6, subject = "Histoire-Géographie", teacherName = "M. Fournier", room = "Salle 302", dayOfWeek = 3, startTime = "08:00", endTime = "10:00", colorHex = "#EC4899"),
                CourseSession(id = 7, subject = "Mathématiques (TD)", teacherName = "M. Laurent", room = "Salle Info 2", dayOfWeek = 4, startTime = "09:00", endTime = "11:00", colorHex = "#1D4ED8"),
                CourseSession(id = 8, subject = "EPS (Gymnase)", teacherName = "M. Girard", room = "Gymnase A", dayOfWeek = 5, startTime = "14:00", endTime = "16:00", colorHex = "#06B6D4")
            )
            dao.insertCourses(courses)

            // Seed Homeworks
            val homeworks = listOf(
                Homework(
                    id = 1,
                    studentId = 1,
                    subject = "Mathématiques",
                    title = "Exercices 42 à 45 page 128 - Dérivées",
                    description = "Étudier les variations et tracer les courbes des fonctions exponentielles.",
                    dueDate = "Demain - 08:00",
                    dueTimestamp = now + (24 * hourMs),
                    isCompleted = false,
                    estimatedMinutes = 50,
                    priority = "HAUTE"
                ),
                Homework(
                    id = 2,
                    studentId = 1,
                    subject = "Physique-Chimie",
                    title = "Compte-rendu du TP Optique et Spectres",
                    description = "Rédiger l'analyse des longueurs d'ondes et calculer l'incertitude type.",
                    dueDate = "Jeudi - 14:00",
                    dueTimestamp = now + (48 * hourMs),
                    isCompleted = false,
                    estimatedMinutes = 60,
                    priority = "MOYENNE"
                ),
                Homework(
                    id = 3,
                    studentId = 1,
                    subject = "Philosophie",
                    title = "Plan détaillé de dissertation",
                    description = "Sujet : « La technique nous libère-t-elle ou nous aliène-t-elle ? »",
                    dueDate = "Vendredi - 13:30",
                    dueTimestamp = now + (72 * hourMs),
                    isCompleted = true,
                    estimatedMinutes = 45,
                    priority = "MOYENNE"
                ),
                Homework(
                    id = 4,
                    studentId = 1,
                    subject = "Anglais LV1",
                    title = "Oral presentation on Artificial Intelligence in Education",
                    description = "Prepare 3-minute speech with key vocabulary.",
                    dueDate = "Lundi prochain",
                    dueTimestamp = now + (120 * hourMs),
                    isCompleted = false,
                    estimatedMinutes = 30,
                    priority = "BASSE"
                )
            )
            dao.insertHomeworks(homeworks)

            // Seed Grades
            val grades = listOf(
                Grade(id = 1, studentId = 1, subject = "Mathématiques", title = "Devoir Surveillé n°2 - Analyse", score = 17.5, maxScore = 20.0, coefficient = 2.0, date = "02 Octobre", teacherFeedback = "Excellente rigueur dans les démonstrations."),
                Grade(id = 2, studentId = 1, subject = "Physique-Chimie", title = "Évaluation - Mécanique Newtonienne", score = 15.0, maxScore = 20.0, coefficient = 2.0, date = "28 Septembre", teacherFeedback = "Très bon raisonnement, attention aux unités."),
                Grade(id = 3, studentId = 1, subject = "Philosophie", title = "Commentaire de texte (Kant)", score = 14.5, maxScore = 20.0, coefficient = 1.0, date = "25 Septembre", teacherFeedback = "Bonne problématisation."),
                Grade(id = 4, studentId = 1, subject = "Anglais LV1", title = "Compréhension écrite & Expression", score = 18.0, maxScore = 20.0, coefficient = 1.0, date = "22 Septembre", teacherFeedback = "Vocabulaire riche et précis, bravo !"),
                Grade(id = 5, studentId = 1, subject = "SVT", title = "TP Génétique & Mitose", score = 16.0, maxScore = 20.0, coefficient = 1.5, date = "19 Septembre", teacherFeedback = "Manipulations soignées et conclusions claires.")
            )
            dao.insertGrades(grades)

            // Seed Announcements
            val announcements = listOf(
                Announcement(
                    id = 1,
                    title = "🚨 Protocole d'accès & Vigipirate renforcé",
                    content = "Rappel à l'ensemble des élèves et personnels : le badge avec QR code est strictement obligatoire dès le portail. Aucun accès sans pointage numérique.",
                    category = "URGENT",
                    author = "Direction de la Sécurité",
                    date = "Aujourd'hui - 07:30",
                    isPinned = true
                ),
                Announcement(
                    id = 2,
                    title = "🏆 Forum des Grandes Écoles & Orientation",
                    content = "Ce vendredi 15h00 au gymnase principal : rencontrez plus de 30 écoles d'ingénieurs, universités et classes préparatoires.",
                    category = "EVENEMENT",
                    author = "Service Orientation",
                    date = "Hier - 14:00",
                    isPinned = false
                ),
                Announcement(
                    id = 3,
                    title = "📢 Réunion Parents-Professeurs du 1er Trimestre",
                    content = "Les créneaux de prise de rendez-vous individuels sont désormais ouverts sur l'Espace Parents SmartCampus.",
                    category = "ACADEMIQUE",
                    author = "Secrétariat Pédagogique",
                    date = "03 Octobre",
                    isPinned = false
                ),
                Announcement(
                    id = 4,
                    title = "🛠️ Maintenance des casiers & badgeuses Bâtiment C",
                    content = "Les travaux s'effectueront mercredi après-midi. Veuillez utiliser le point d'accès Bâtiment A.",
                    category = "VIE_SCOLAIRE",
                    author = "Vie Scolaire",
                    date = "01 Octobre",
                    isPinned = false
                )
            )
            dao.insertAnnouncements(announcements)

            // Seed Incident / Security reports
            val incidents = listOf(
                IncidentReport(
                    id = 1,
                    reporterName = "Surveillant Ahmed",
                    reporterRole = "Surveillant",
                    type = "SECURITE",
                    location = "Portail Ouest",
                    description = "Tentative d'intrusion d'une personne extérieure sans badge QR. Refoulée par la sécurité.",
                    emergencyLevel = "ELEVEE",
                    status = "RESOLU",
                    timestamp = now - (3 * hourMs),
                    resolvedNote = "Portail sécurisé, vérification des caméras effectuée."
                ),
                IncidentReport(
                    id = 2,
                    reporterName = "Lucas Dubois",
                    reporterRole = "Élève",
                    type = "URGENCE_MEDICALE",
                    location = "Gymnase A",
                    description = "Un élève s'est blessé à la cheville pendant l'échauffement de basket-ball.",
                    emergencyLevel = "ELEVEE",
                    status = "RESOLU",
                    timestamp = now - (26 * hourMs),
                    resolvedNote = "Pris en charge par l'infirmerie scolaire. Famille informée."
                )
            )
            for (inc in incidents) {
                dao.insertIncident(inc)
            }
        }
    }
}
