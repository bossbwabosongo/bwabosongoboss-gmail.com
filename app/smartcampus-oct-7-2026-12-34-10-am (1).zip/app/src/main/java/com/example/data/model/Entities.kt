package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "students")
data class Student(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val matricule: String, // e.g. "SC-2024-101"
    val firstName: String,
    val lastName: String,
    val className: String, // e.g. "Terminale S1"
    val birthDate: String,
    val bloodGroup: String = "O+",
    val parentName: String,
    val parentPhone: String,
    val email: String,
    val avatarColorHex: String = "#1D4ED8",
    val qrCodePayload: String // e.g. "SMARTCAMPUS:STUDENT:SC-2024-101:Lucas:Dubois:Terminale S1"
) {
    val fullName: String get() = "$firstName $lastName"
}

@Entity(tableName = "attendance_records")
data class AttendanceRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val studentId: Long,
    val studentMatricule: String,
    val studentName: String,
    val className: String,
    val timestamp: Long = System.currentTimeMillis(),
    val type: String, // "ENTREE", "SORTIE"
    val status: String, // "A_L_HEURE", "RETARD", "JUSTIFIE"
    val checkpoint: String = "Portail Principal",
    val scannedBy: String = "Borne Sécurité A"
)

@Entity(tableName = "courses")
data class CourseSession(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val subject: String,
    val teacherName: String,
    val room: String,
    val dayOfWeek: Int, // 1 = Lundi, 2 = Mardi, ..., 5 = Vendredi
    val startTime: String, // "08:00"
    val endTime: String, // "10:00"
    val colorHex: String = "#2563EB",
    val className: String = "Terminale S1"
)

@Entity(tableName = "homeworks")
data class Homework(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val studentId: Long = 1,
    val subject: String,
    val title: String,
    val description: String,
    val dueDate: String, // "10 Octobre 2026"
    val dueTimestamp: Long,
    val isCompleted: Boolean = false,
    val estimatedMinutes: Int = 45,
    val priority: String = "MOYENNE" // "HAUTE", "MOYENNE", "BASSE"
)

@Entity(tableName = "grades")
data class Grade(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val studentId: Long = 1,
    val subject: String,
    val title: String,
    val score: Double, // e.g. 16.5
    val maxScore: Double = 20.0,
    val coefficient: Double = 1.0,
    val date: String,
    val teacherFeedback: String = "Très bon travail"
)

@Entity(tableName = "announcements")
data class Announcement(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val content: String,
    val category: String, // "URGENT", "EVENEMENT", "ACADEMIQUE", "VIE_SCOLAIRE"
    val author: String,
    val date: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isPinned: Boolean = false
)

@Entity(tableName = "incidents")
data class IncidentReport(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val reporterName: String,
    val reporterRole: String, // "Élève", "Parent", "Surveillant", "Enseignant"
    val type: String, // "URGENCE_MEDICALE", "SECURITE", "ACCIDENT", "HARCELEMENT", "DEGRADATION", "AUTRE"
    val location: String, // e.g. "Cour Centrale", "Bâtiment B - Salle 204", "Cantine"
    val description: String,
    val emergencyLevel: String, // "URGENCE_SOS", "ELEVEE", "NORMALE"
    val status: String = "EN_COURS", // "SIGNALÉ", "EN_COURS", "RÉSOLU"
    val timestamp: Long = System.currentTimeMillis(),
    val resolvedNote: String = ""
)
