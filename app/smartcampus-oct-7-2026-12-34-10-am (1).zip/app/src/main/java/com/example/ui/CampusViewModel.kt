package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.model.Announcement
import com.example.data.model.AttendanceRecord
import com.example.data.model.CourseSession
import com.example.data.model.Grade
import com.example.data.model.Homework
import com.example.data.model.IncidentReport
import com.example.data.model.Student
import com.example.data.repository.CampusRepository
import com.example.data.repository.ScanResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class UserRole(val label: String, val subtitle: String) {
    STUDENT("Élève", "Lucas Dubois (Terminale S1)"),
    PARENT("Parent d'élève", "Espace Famille Dubois"),
    SECURITY("Agent / Borne Sécurité", "Poste de contrôle Entrée Principale")
}

enum class NavigationTab(val title: String) {
    DASHBOARD("Accueil"),
    COURSES("Cours & Devoirs"),
    ATTENDANCE("Badge & Présences"),
    GRADES("Notes & Résultats"),
    SECURITY("Sécurité & SOS")
}

data class CampusUiState(
    val currentRole: UserRole = UserRole.STUDENT,
    val currentTab: NavigationTab = NavigationTab.DASHBOARD,
    val selectedStudentId: Long = 1,
    val lastScanResult: ScanResult? = null,
    val isSimulatingScan: Boolean = false,
    val showEmergencyDialog: Boolean = false,
    val showAddHomeworkDialog: Boolean = false,
    val bannerNotice: String? = null
)

class CampusViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: CampusRepository

    private val _uiState = MutableStateFlow(CampusUiState())
    val uiState: StateFlow<CampusUiState> = _uiState.asStateFlow()

    init {
        val db = AppDatabase.getDatabase(application, viewModelScope)
        repository = CampusRepository(db.campusDao())

        // Ensure database has seed data if needed
        viewModelScope.launch(Dispatchers.IO) {
            // Room DB seed happens via callback, but if already created without seed, populate here
            try {
                val existing = db.campusDao().getStudentByMatricule("SC-2024-001")
                if (existing == null) {
                    AppDatabase.populateInitialData(db.campusDao())
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    val students: StateFlow<List<Student>> = repository.students
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val attendanceRecords: StateFlow<List<AttendanceRecord>> = repository.attendanceRecords
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val courses: StateFlow<List<CourseSession>> = repository.courses
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val homeworks: StateFlow<List<Homework>> = repository.homeworks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val grades: StateFlow<List<Grade>> = repository.grades
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val announcements: StateFlow<List<Announcement>> = repository.announcements
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val incidents: StateFlow<List<IncidentReport>> = repository.incidents
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Current selected student
    val currentStudent: StateFlow<Student?> = combine(students, _uiState) { list, state ->
        list.find { it.id == state.selectedStudentId } ?: list.firstOrNull()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    fun setRole(role: UserRole) {
        _uiState.value = _uiState.value.copy(currentRole = role)
    }

    fun setTab(tab: NavigationTab) {
        _uiState.value = _uiState.value.copy(currentTab = tab)
    }

    fun setSelectedStudent(studentId: Long) {
        _uiState.value = _uiState.value.copy(selectedStudentId = studentId)
    }

    fun toggleHomework(homework: Homework) {
        viewModelScope.launch {
            repository.toggleHomework(homework)
        }
    }

    fun addHomework(subject: String, title: String, description: String, dueDate: String, priority: String) {
        viewModelScope.launch {
            val hw = Homework(
                studentId = _uiState.value.selectedStudentId,
                subject = subject,
                title = title,
                description = description,
                dueDate = dueDate,
                dueTimestamp = System.currentTimeMillis() + 86400000L,
                priority = priority
            )
            repository.addHomework(hw)
            _uiState.value = _uiState.value.copy(showAddHomeworkDialog = false)
        }
    }

    fun deleteHomework(id: Long) {
        viewModelScope.launch {
            repository.deleteHomework(id)
        }
    }

    fun triggerQuickSos(location: String) {
        viewModelScope.launch {
            val studentName = currentStudent.value?.fullName ?: "Utilisateur SmartCampus"
            val incident = IncidentReport(
                reporterName = studentName,
                reporterRole = _uiState.value.currentRole.label,
                type = "SECURITE",
                location = location,
                description = "🚨 ALERTE SOS DÉCLENCHÉE EN URGENCE depuis l'application SmartCampus.",
                emergencyLevel = "URGENCE_SOS",
                status = "EN_COURS",
                timestamp = System.currentTimeMillis()
            )
            repository.addIncident(incident)
            _uiState.value = _uiState.value.copy(
                showEmergencyDialog = false,
                bannerNotice = "🚨 Alerte SOS envoyée au poste de sécurité central !"
            )
        }
    }

    fun reportIncident(type: String, location: String, description: String, level: String) {
        viewModelScope.launch {
            val reporter = currentStudent.value?.fullName ?: "Utilisateur"
            val incident = IncidentReport(
                reporterName = reporter,
                reporterRole = _uiState.value.currentRole.label,
                type = type,
                location = location,
                description = description,
                emergencyLevel = level,
                status = "SIGNALÉ",
                timestamp = System.currentTimeMillis()
            )
            repository.addIncident(incident)
            _uiState.value = _uiState.value.copy(
                bannerNotice = "Signalement enregistré. Les équipes ont été notifiées."
            )
        }
    }

    fun resolveIncident(id: Long, note: String) {
        viewModelScope.launch {
            repository.updateIncidentStatus(id, "RESOLU", note)
        }
    }

    fun processBadgeScan(payload: String, type: String = "ENTREE", checkpoint: String = "Portail Principal") {
        viewModelScope.launch {
            val result = repository.scanAndProcessBadge(payload, type, checkpoint)
            _uiState.value = _uiState.value.copy(lastScanResult = result)
        }
    }

    fun clearLastScanResult() {
        _uiState.value = _uiState.value.copy(lastScanResult = null)
    }

    fun dismissBannerNotice() {
        _uiState.value = _uiState.value.copy(bannerNotice = null)
    }

    fun setShowEmergencyDialog(show: Boolean) {
        _uiState.value = _uiState.value.copy(showEmergencyDialog = show)
    }

    fun setShowAddHomeworkDialog(show: Boolean) {
        _uiState.value = _uiState.value.copy(showAddHomeworkDialog = show)
    }
}
