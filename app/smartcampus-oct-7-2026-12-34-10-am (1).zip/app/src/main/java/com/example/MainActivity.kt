package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.CampusViewModel
import com.example.ui.NavigationTab
import com.example.ui.components.AddHomeworkDialog
import com.example.ui.components.CampusAppBar
import com.example.ui.components.CampusBottomBar
import com.example.ui.components.EmergencySosDialog
import com.example.ui.components.ScanResultDialog
import com.example.ui.screens.AttendanceScreen
import com.example.ui.screens.CoursesScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.GradesScreen
import com.example.ui.screens.SecurityScreen
import com.example.ui.theme.SmartCampusTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SmartCampusTheme {
                SmartCampusApp()
            }
        }
    }
}

@Composable
fun SmartCampusApp(viewModel: CampusViewModel = viewModel()) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val students by viewModel.students.collectAsStateWithLifecycle()
    val currentStudent by viewModel.currentStudent.collectAsStateWithLifecycle()
    val attendanceRecords by viewModel.attendanceRecords.collectAsStateWithLifecycle()
    val courses by viewModel.courses.collectAsStateWithLifecycle()
    val homeworks by viewModel.homeworks.collectAsStateWithLifecycle()
    val grades by viewModel.grades.collectAsStateWithLifecycle()
    val announcements by viewModel.announcements.collectAsStateWithLifecycle()
    val incidents by viewModel.incidents.collectAsStateWithLifecycle()

    // Handle back button navigation to return to Dashboard
    if (uiState.currentTab != NavigationTab.DASHBOARD) {
        BackHandler {
            viewModel.setTab(NavigationTab.DASHBOARD)
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            CampusAppBar(
                currentRole = uiState.currentRole,
                onRoleSelected = { role -> viewModel.setRole(role) },
                onSosClick = { viewModel.setShowEmergencyDialog(true) },
                bannerNotice = uiState.bannerNotice,
                onDismissBanner = { viewModel.dismissBannerNotice() }
            )
        },
        bottomBar = {
            CampusBottomBar(
                currentTab = uiState.currentTab,
                onTabSelected = { tab -> viewModel.setTab(tab) }
            )
        }
    ) { innerPadding ->
        val screenModifier = Modifier
            .fillMaxSize()
            .padding(innerPadding)

        when (uiState.currentTab) {
            NavigationTab.DASHBOARD -> {
                DashboardScreen(
                    currentRole = uiState.currentRole,
                    student = currentStudent,
                    courses = courses,
                    homeworks = homeworks,
                    attendanceRecords = attendanceRecords,
                    announcements = announcements,
                    onNavigateTab = { tab -> viewModel.setTab(tab) },
                    modifier = screenModifier
                )
            }
            NavigationTab.COURSES -> {
                CoursesScreen(
                    courses = courses,
                    homeworks = homeworks,
                    onToggleHomework = { hw -> viewModel.toggleHomework(hw) },
                    onDeleteHomework = { id -> viewModel.deleteHomework(id) },
                    onAddHomeworkClick = { viewModel.setShowAddHomeworkDialog(true) },
                    modifier = screenModifier
                )
            }
            NavigationTab.ATTENDANCE -> {
                AttendanceScreen(
                    currentStudent = currentStudent,
                    allStudents = students,
                    attendanceRecords = attendanceRecords,
                    onSelectStudent = { id -> viewModel.setSelectedStudent(id) },
                    onScanPayload = { payload, type, checkpoint ->
                        viewModel.processBadgeScan(payload, type, checkpoint)
                    },
                    modifier = screenModifier
                )
            }
            NavigationTab.GRADES -> {
                GradesScreen(
                    grades = grades,
                    modifier = screenModifier
                )
            }
            NavigationTab.SECURITY -> {
                SecurityScreen(
                    announcements = announcements,
                    incidents = incidents,
                    onTriggerSos = { loc -> viewModel.triggerQuickSos(loc) },
                    onReportIncident = { type, loc, desc, level ->
                        viewModel.reportIncident(type, loc, desc, level)
                    },
                    onResolveIncident = { id, note ->
                        viewModel.resolveIncident(id, note)
                    },
                    modifier = screenModifier
                )
            }
        }
    }

    // Dialogs
    uiState.lastScanResult?.let { scanResult ->
        ScanResultDialog(
            result = scanResult,
            onDismiss = { viewModel.clearLastScanResult() }
        )
    }

    if (uiState.showEmergencyDialog) {
        EmergencySosDialog(
            onDismiss = { viewModel.setShowEmergencyDialog(false) },
            onConfirmSos = { location -> viewModel.triggerQuickSos(location) }
        )
    }

    if (uiState.showAddHomeworkDialog) {
        AddHomeworkDialog(
            onDismiss = { viewModel.setShowAddHomeworkDialog(false) },
            onAdd = { subject, title, desc, due, priority ->
                viewModel.addHomework(subject, title, desc, due, priority)
            }
        )
    }
}
