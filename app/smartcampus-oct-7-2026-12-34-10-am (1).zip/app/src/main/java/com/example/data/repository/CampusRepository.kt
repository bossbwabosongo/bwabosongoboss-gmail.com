package com.example.data.repository

import com.example.data.dao.CampusDao
import com.example.data.model.Announcement
import com.example.data.model.AttendanceRecord
import com.example.data.model.CourseSession
import com.example.data.model.Grade
import com.example.data.model.Homework
import com.example.data.model.IncidentReport
import com.example.data.model.Student
import com.example.util.QrCodeDecoder
import kotlinx.coroutines.flow.Flow
import java.util.Calendar

sealed class ScanResult {
    data class Success(
        val student: Student,
        val record: AttendanceRecord,
        val message: String
    ) : ScanResult()

    data class Error(val message: String) : ScanResult()
}

class CampusRepository(private val dao: CampusDao) {

    val students: Flow<List<Student>> = dao.getAllStudents()
    val attendanceRecords: Flow<List<AttendanceRecord>> = dao.getAllAttendance()
    val courses: Flow<List<CourseSession>> = dao.getAllCourses()
    val homeworks: Flow<List<Homework>> = dao.getAllHomework()
    val grades: Flow<List<Grade>> = dao.getAllGrades()
    val announcements: Flow<List<Announcement>> = dao.getAllAnnouncements()
    val incidents: Flow<List<IncidentReport>> = dao.getAllIncidents()

    fun getStudentAttendance(studentId: Long): Flow<List<AttendanceRecord>> =
        dao.getAttendanceForStudent(studentId)

    fun getStudentHomework(studentId: Long): Flow<List<Homework>> =
        dao.getHomeworkForStudent(studentId)

    fun getStudentGrades(studentId: Long): Flow<List<Grade>> =
        dao.getGradesForStudent(studentId)

    suspend fun toggleHomework(homework: Homework) {
        dao.updateHomework(homework.copy(isCompleted = !homework.isCompleted))
    }

    suspend fun addHomework(homework: Homework): Long {
        return dao.insertHomework(homework)
    }

    suspend fun deleteHomework(id: Long) {
        dao.deleteHomework(id)
    }

    suspend fun addIncident(incident: IncidentReport): Long {
        return dao.insertIncident(incident)
    }

    suspend fun updateIncidentStatus(id: Long, status: String, note: String) {
        dao.updateIncidentStatus(id, status, note)
    }

    suspend fun addAnnouncement(announcement: Announcement): Long {
        return dao.insertAnnouncement(announcement)
    }

    suspend fun scanAndProcessBadge(
        payload: String,
        type: String = "ENTREE",
        checkpoint: String = "Portail Principal"
    ): ScanResult {
        val parsed = QrCodeDecoder.parsePayload(payload)
        // Find student in DB by matricule or payload
        val student = dao.getStudentByMatricule(parsed.matricule)
            ?: dao.getStudentByPayload(payload)

        if (student == null) {
            return ScanResult.Error("Badge non reconnu : aucun élève trouvé avec le matricule \"${parsed.matricule}\"")
        }

        // Determine timeliness (e.g. before 08:15 is ON_TIME)
        val calendar = Calendar.getInstance()
        val hour = calendar.get(Calendar.HOUR_OF_DAY)
        val minute = calendar.get(Calendar.MINUTE)
        val isLate = if (type == "ENTREE") {
            (hour > 8 || (hour == 8 && minute > 15))
        } else false

        val status = if (isLate) "RETARD" else "A_L_HEURE"

        val record = AttendanceRecord(
            studentId = student.id,
            studentMatricule = student.matricule,
            studentName = student.fullName,
            className = student.className,
            timestamp = System.currentTimeMillis(),
            type = type,
            status = status,
            checkpoint = checkpoint,
            scannedBy = "Borne Sécurité"
        )

        dao.insertAttendance(record)

        val message = when (type) {
            "ENTREE" -> if (isLate) {
                "⚠️ Entrée enregistrée avec RETARD pour ${student.fullName} (${student.className})"
            } else {
                "✅ Entrée validée pour ${student.fullName} (${student.className})"
            }
            else -> "🚪 Sortie autorisée pour ${student.fullName} (${student.className})"
        }

        return ScanResult.Success(student, record, message)
    }
}
