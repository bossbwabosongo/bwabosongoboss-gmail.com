package com.example.util

import android.graphics.Bitmap
import com.google.zxing.BinaryBitmap
import com.google.zxing.MultiFormatReader
import com.google.zxing.RGBLuminanceSource
import com.google.zxing.common.HybridBinarizer

data class ParsedStudentQr(
    val matricule: String,
    val firstName: String,
    val lastName: String,
    val className: String,
    val rawPayload: String
)

object QrCodeDecoder {

    fun parsePayload(payload: String): ParsedStudentQr {
        val trimmed = payload.trim()
        if (trimmed.startsWith("SMARTCAMPUS:STUDENT:")) {
            val parts = trimmed.split(":")
            if (parts.size >= 6) {
                return ParsedStudentQr(
                    matricule = parts[2],
                    firstName = parts[3],
                    lastName = parts[4],
                    className = parts[5],
                    rawPayload = trimmed
                )
            }
        }
        // Fallback for direct matricule or text
        return ParsedStudentQr(
            matricule = trimmed,
            firstName = "",
            lastName = "",
            className = "",
            rawPayload = trimmed
        )
    }

    fun decodeBitmap(bitmap: Bitmap): String? {
        return try {
            val width = bitmap.width
            val height = bitmap.height
            val pixels = IntArray(width * height)
            bitmap.getPixels(pixels, 0, width, 0, 0, width, height)
            val source = RGBLuminanceSource(width, height, pixels)
            val binaryBitmap = BinaryBitmap(HybridBinarizer(source))
            val reader = MultiFormatReader()
            val result = reader.decode(binaryBitmap)
            result.text
        } catch (e: Exception) {
            null
        }
    }
}
